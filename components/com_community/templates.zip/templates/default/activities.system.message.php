<div class="cStream-Content">
	<div class="cStream-Quote">
		<b><?php echo CActivities::format($this->act->title); ?></b>
	</div>
	<?php $this->load('activities.actions'); ?>
</div>