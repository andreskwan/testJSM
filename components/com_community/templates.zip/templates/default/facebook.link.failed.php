<?php
defined('_JEXEC') or die();
?>
<div><?php echo $login->message;?></div>